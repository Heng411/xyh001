package com.mscs.goodsview;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.mscs.util.DbUtil;
import com.mscs.util.StringUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class GoodsAdd extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField nameText;
	private JTextField RepText;
	private JTextField PriceText;
	private JButton save;
	private JTextField saleText;
	private JTextField demandText;

	public GoodsAdd() {
		setTitle("��Ʒ����");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 453, 464);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel namelabel = new JLabel("����");
		namelabel.setBounds(123, 49, 61, 18);
		contentPane.add(namelabel);
		
		JLabel RepLabel = new JLabel("���");
		RepLabel.setBounds(123, 92, 72, 18);
		contentPane.add(RepLabel);
		
		JLabel PriceLabel = new JLabel("�۸�");
		PriceLabel.setBounds(123, 133, 72, 18);
		contentPane.add(PriceLabel);
		
		nameText = new JTextField();
		nameText.setBounds(219, 46, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		RepText = new JTextField();
		RepText.setBounds(219, 89, 86, 24);
		contentPane.add(RepText);
		RepText.setColumns(10);
		
		PriceText = new JTextField();
		PriceText.setBounds(219, 126, 86, 24);
		contentPane.add(PriceText);
		PriceText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.addActionListener(this);
		save.setBounds(308, 377, 113, 27);
		contentPane.add(save);
		
		JLabel SaleLabel = new JLabel("���۳�");
		SaleLabel.setBounds(123, 176, 72, 18);
		contentPane.add(SaleLabel);
		
		saleText = new JTextField();
		saleText.setBounds(219, 173, 86, 24);
		contentPane.add(saleText);
		saleText.setColumns(10);
		
		JLabel demandLabel = new JLabel("������");
		demandLabel.setBounds(123, 220, 72, 18);
		contentPane.add(demandLabel);
		
		demandText = new JTextField();
		demandText.setBounds(219, 217, 86, 24);
		contentPane.add(demandText);
		demandText.setColumns(10);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			String name = nameText.getText();
			int repertory = Integer.parseInt(RepText.getText());
			int price = Integer.parseInt(saleText.getText());
			int sale = Integer.parseInt(PriceText.getText());
			String demand = demandText.getText();
			try {	
				DbUtil db = new DbUtil();
				Statement statement = db.getCon().createStatement();
				String strsql = "select * from goods where  name='"+name+"'";
				ResultSet rs = statement.executeQuery(strsql);
				if(StringUtil.isEmpty(name)){
					JOptionPane.showMessageDialog(null, "��Ʒ���Ʋ���Ϊ��", "����",JOptionPane.WARNING_MESSAGE);
				}else if(StringUtil.isEmpty(Integer.toString(repertory))){
					JOptionPane.showMessageDialog(null, "��Ʒ��治��Ϊ��", "����",JOptionPane.WARNING_MESSAGE);
				}else if(StringUtil.isEmpty(Integer.toString(price))){
					JOptionPane.showMessageDialog(null, "��Ʒ�۸���Ϊ��", "����",JOptionPane.WARNING_MESSAGE);
				}else if(StringUtil.isEmpty(Integer.toString(sale))){
					JOptionPane.showMessageDialog(null, "��Ʒ���۳�������Ϊ��", "����",JOptionPane.WARNING_MESSAGE);
				}else if(StringUtil.isEmpty(demand)){
					JOptionPane.showMessageDialog(null, "��Ʒ����������Ϊ��", "����",JOptionPane.WARNING_MESSAGE);
				}else if(rs.next()){
					JOptionPane.showMessageDialog(null, "��Ʒ�Ѵ���", "����",JOptionPane.WARNING_MESSAGE);
				}else{
					String sql = "insert into goods(name,repertory,price,sale,demand) values ('"+name+"','"+repertory+"','"+price+"','"+sale+"','"+demand+"')";
					statement.execute(sql);
				}
				
				db.getCon().close();
				
				} catch (ClassNotFoundException ee) {
					// ���ݿ��������쳣����
					System.out.println("Sorry,can`t find the Driver!");
					ee.printStackTrace();
				} catch (SQLException ee) {
					// ���ݿ�����ʧ���쳣����
					ee.printStackTrace();
				} catch (Exception ee) {
					// TODO: handle exception
					ee.printStackTrace();
				}
			this.dispose();

		}
			
	}
}
