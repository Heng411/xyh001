package com.mscs.goodsview;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.mscs.util.DbUtil;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class GoodsSearch extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField repText;
	private JTextField priceText;
	private JButton save;
	private JLabel saleLabel;
	private JTextField saleText;
	private JLabel demandLabel;
	private JTextField demandText;
	private int id;

	
	public GoodsSearch() {
		setTitle("��Ʒ�鿴");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����		
		setBounds(100, 100, 454, 492);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("ID");
		idLabel.setBounds(72, 66, 72, 18);
		contentPane.add(idLabel);
		
		IdText = new JTextField();
		IdText.setEditable(false);
		IdText.setBounds(169, 63, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(72, 126, 72, 18);
		contentPane.add(nameLabel);
		
		nameText = new JTextField();
		nameText.setEditable(false);
		nameText.setBounds(169, 123, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		JLabel RepLabel = new JLabel("�����");
		RepLabel.setBounds(72, 178, 72, 18);
		contentPane.add(RepLabel);
		
		repText = new JTextField();
		repText.setEditable(false);
		repText.setBounds(169, 175, 86, 24);
		contentPane.add(repText);
		repText.setColumns(10);
		
		JLabel rankLabel = new JLabel("�۸�");
		rankLabel.setBounds(72, 228, 72, 18);
		contentPane.add(rankLabel);
		
		priceText = new JTextField();
		priceText.setEditable(false);
		priceText.setBounds(169, 225, 86, 24);
		contentPane.add(priceText);
		priceText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(325, 390, 113, 27);
		contentPane.add(save);
		save.addActionListener(this);
		
		saleLabel = new JLabel("���۳�");
		saleLabel.setBounds(72, 276, 72, 18);
		contentPane.add(saleLabel);
		
		saleText = new JTextField();
		saleText.setEditable(false);
		saleText.setBounds(169, 273, 86, 24);
		contentPane.add(saleText);
		saleText.setColumns(10);
		
		demandLabel = new JLabel("������");
		demandLabel.setBounds(72, 320, 72, 18);
		contentPane.add(demandLabel);
		
		demandText = new JTextField();
		demandText.setEditable(false);
		demandText.setBounds(169, 317, 86, 24);
		contentPane.add(demandText);
		demandText.setColumns(10);
	}
	
	public void setId(int a ){
		this.id = a;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			this.dispose();;
		}
	}
	
	public void getInfo(){
		
		// ������ѯ�����
		try {
			
			DbUtil db = new DbUtil();
			Statement statement = db.getCon().createStatement();	
			String sql = "select * from goods where id='"+id+"'";

			ResultSet rs = statement.executeQuery(sql);
			if(rs.next()){
				IdText.setText(rs.getString("id"));
				nameText.setText(rs.getString("name"));
				repText.setText(String.valueOf(rs.getInt("repertory")));
				priceText.setText(String.valueOf(rs.getInt("price")));	
				saleText.setText(String.valueOf(rs.getInt("sale")));	
				demandText.setText(String.valueOf(rs.getInt("demand")));	
				this.setVisible(true);
			}
			else{
				JOptionPane.showMessageDialog(null, "�û�������", "����",JOptionPane.WARNING_MESSAGE); 
			}

			rs.close();
			db.getCon().close();
		} catch (ClassNotFoundException e) {
			// ���ݿ��������쳣����
			System.out.println("Sorry,can`t find the Driver!");
			e.printStackTrace();
		} catch (SQLException e) {
			// ���ݿ�����ʧ���쳣����
			e.printStackTrace();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
