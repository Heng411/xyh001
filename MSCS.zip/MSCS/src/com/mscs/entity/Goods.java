package com.mscs.entity;

public class Goods {
	String name;
	double ID;
	int repertory;
	int sale;
	String demand;
	

}
