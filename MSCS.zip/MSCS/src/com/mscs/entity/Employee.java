package com.mscs.entity;

public class Employee {
	String name;
	String position;
	String remark;
	double ID;
	double ID_key;
	int salary;

}
