package com.mscs.entity;

public class VIP {
	String name;
	double ID;
	int score;
	int rank;

}
