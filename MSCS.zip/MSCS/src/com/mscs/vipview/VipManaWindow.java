package com.mscs.vipview;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.mscs.util.DbUtil;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;

public class VipManaWindow extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTable infoTable;
	private Vector<Object> ve; 
	private JButton add ;
	private JButton update;
	private JButton delete;
	private JButton search;
	private JButton refresh;
	private int DelID;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VipManaWindow frame = new VipManaWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public VipManaWindow()  {
		setResizable(false);
		setTitle("��Ա����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 712, 474);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel showInfo = new JPanel();
		showInfo.setBounds(0, 46, 694, 381);
		contentPane.add(showInfo);
		showInfo.setLayout(null);
		
		String[] columnNames = {"���","����","����","�ȼ�","�ֻ���"};
		Object[][] rowDatas = {};
		
		DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
		infoTable = new JTable(myModel);
		infoTable.setBounds(39, 13, 586, 322);
		
		try {
			getInfo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// ���ñ���������ɫ
		infoTable.setForeground(Color.BLACK);                   // ������ɫ
		infoTable.setFont(new Font(null, Font.PLAIN, 14));      // ������ʽ
		infoTable.setSelectionForeground(Color.DARK_GRAY);      // ѡ�к�������ɫ
		infoTable.setSelectionBackground(Color.LIGHT_GRAY);     // ѡ�к����屳��
		infoTable.setGridColor(Color.GRAY);                     // ������ɫ

        // ���ñ�ͷ
		infoTable.getTableHeader().setFont(new Font(null, Font.BOLD, 14));  // ���ñ�ͷ����������ʽ
		infoTable.getTableHeader().setForeground(Color.RED);                // ���ñ�ͷ����������ɫ
		infoTable.getTableHeader().setResizingAllowed(false);               // ���ò������ֶ��ı��п�
		infoTable.getTableHeader().setReorderingAllowed(false);             // ���ò������϶������������
		 // �����и�
		infoTable.setRowHeight(30);
		
		JScrollPane scrollPane = new JScrollPane(infoTable);
		scrollPane.setBounds(0, 13, 694, 343);
		showInfo.add(scrollPane);
		
		JPanel function = new JPanel();
		function.setBounds(0, 0, 694, 47);
		contentPane.add(function);
		
		add = new JButton("����");
		add.setIcon(new ImageIcon(VipManaWindow.class.getResource("/image/adduser.ico")));
		add.setBounds(14, 0, 120, 34);
		add.addActionListener(this); 
		
		function.setLayout(null);
		function.add(add);
		
		update = new JButton("�޸�");
		update.setBounds(148, 0, 120, 34);
		update.addActionListener(this);
		function.add(update);
		
		delete = new JButton("ɾ��");
		delete.setBounds(282, 0, 120, 34);
		delete.addActionListener(this);
		function.add(delete);
		
		search = new JButton("����");
		search.setBounds(416, 0, 120, 34);
		search.addActionListener(this);
		function.add(search);
		
		refresh = new JButton("ˢ��");
		refresh.addActionListener(this);
		refresh.setBounds(550, 0, 115, 31);
		function.add(refresh);
}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(add)){
			VipAdd vipadd = new VipAdd();
		}
		if(e.getSource().equals(refresh)){
			this.dispose();
			VipManaWindow vw = new VipManaWindow();
			vw.setVisible(true);
		}
		if(e.getSource().equals(delete)){
			int del = infoTable.getSelectedRow();
			DelID = Integer.parseInt(infoTable.getValueAt(del, 0).toString());
			int n = JOptionPane.showConfirmDialog(null, "�Ƿ�ȷ��ɾ��?", "��Աɾ��",JOptionPane.YES_NO_OPTION);//i=0/1  
			if(n==0){	
				try {
					delInfo();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		if(e.getSource().equals(update)){
			int row = infoTable.getSelectedRow();
			VipUpdate alter = new VipUpdate();
			alter.setTemp(row);
			alter.setVisible(true);
			alter.setTable(infoTable);
		}
		if(e.getSource().equals(search)){
			String id = JOptionPane.showInputDialog("��������Ʒ��ţ�");
			Vipsearch sea = new Vipsearch();
			sea.setId(Integer.parseInt(id));
			try {
				sea.getInfo();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	public void getInfo()throws Exception{
		String[] columnNames = {"���","����","����","�ȼ�","�ֻ���"};
		Object[][] rowDatas = {};
		
		DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
		infoTable = new JTable(myModel);
		
		DbUtil db = new DbUtil();
		Statement statement = 	db.getCon().createStatement();
		String sql = "select * from VIP";

		ResultSet rs = statement.executeQuery(sql);
		
		while (rs.next()) {
			ve = new Vector<Object>();
			ve.addElement(rs.getString("id")); 
			ve.addElement(rs.getString("name"));
			ve.addElement(rs.getInt("score"));
			ve.addElement(rs.getInt("rank"));
			ve.addElement(rs.getString("phone"));
			myModel.addRow(ve);
		}
		rs.close();
		db.getCon().close();
	}
	
	public void delInfo() throws Exception{
		// ������ѯ�����
		DbUtil db = new DbUtil();
		Statement statement = 	db.getCon().createStatement();
		String sql = "delete from vip where id = '"+DelID+"'";
		statement.execute(sql);
		db.getCon().close();
		
	}
}

