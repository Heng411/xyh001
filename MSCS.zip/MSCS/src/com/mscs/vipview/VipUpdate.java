package com.mscs.vipview;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import com.mscs.util.DbUtil;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JButton;

public class VipUpdate extends JFrame implements ActionListener{

	private JPanel contentPane;
	private int temp;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField creditText;
	private JTextField rankText;
	private JButton save;
	
	public VipUpdate() {
		setTitle("��Ա�޸�");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 454, 407);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("ID");
		idLabel.setBounds(72, 66, 72, 18);
		contentPane.add(idLabel);
		
		IdText = new JTextField();
		IdText.setBounds(169, 63, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(72, 126, 72, 18);
		contentPane.add(nameLabel);
		
		nameText = new JTextField();
		nameText.setBounds(169, 123, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		JLabel CreditLabel = new JLabel("����");
		CreditLabel.setBounds(72, 178, 72, 18);
		contentPane.add(CreditLabel);
		
		creditText = new JTextField();
		creditText.setBounds(169, 175, 86, 24);
		contentPane.add(creditText);
		creditText.setColumns(10);
		
		JLabel rankLabel = new JLabel("�ȼ�");
		rankLabel.setBounds(72, 228, 72, 18);
		contentPane.add(rankLabel);
		
		rankText = new JTextField();
		rankText.setBounds(169, 225, 86, 24);
		contentPane.add(rankText);
		rankText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(309, 304, 113, 27);
		contentPane.add(save);
		save.addActionListener(this);
		
	}
	public void setTemp(int i){
		this.temp = i;
	}
	public void setTable(JTable table){
	
		IdText.setText(table.getValueAt(temp, 0).toString());
		nameText.setText(table.getValueAt(temp, 1).toString());
		creditText.setText(table.getValueAt(temp, 2).toString());
		rankText.setText(table.getValueAt(temp, 3).toString());
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			int id = Integer.parseInt(IdText.getText());
			String name = nameText.getText();
			int credit = Integer.parseInt(creditText.getText());
			int rank = Integer.parseInt(rankText.getText());
			
			// ������ѯ�����
			try {
				DbUtil db = new DbUtil();
				Statement statement = db.getCon().createStatement();
				String sql = "update vip set name= '"+name+"',score='"+credit+"',rank='"+rank+"' where id= '"+id+"'";

				statement.execute(sql);
			
				db.getCon().close();
				} catch (ClassNotFoundException ee) {
					// ���ݿ��������쳣����
					System.out.println("Sorry,can`t find the Driver!");
					ee.printStackTrace();
				} catch (SQLException ee) {
					// ���ݿ�����ʧ���쳣����
					ee.printStackTrace();
				} catch (Exception ee) {
					ee.printStackTrace();
				}
			this.dispose();

		}
			
	}
	
	
}
