package com.mscs.vipview;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mscs.util.DbUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class Vipsearch extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField creditText;
	private JTextField rankText;
	private JButton save;
	private int id;

	
	public Vipsearch() {
		setTitle("��Ա�鿴");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����		
		setBounds(100, 100, 452, 376);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel IdLabel = new JLabel("ID");
		IdLabel.setBounds(85, 43, 72, 18);
		contentPane.add(IdLabel);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(85, 88, 72, 18);
		contentPane.add(nameLabel);
		
		JLabel creditLabel = new JLabel("����");
		creditLabel.setBounds(85, 136, 72, 18);
		contentPane.add(creditLabel);
		
		JLabel rankLabel = new JLabel("�ȼ�");
		rankLabel.setBounds(85, 178, 72, 18);
		contentPane.add(rankLabel);
		
		IdText = new JTextField();
		IdText.setEditable(false);
		IdText.setBounds(180, 40, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		nameText = new JTextField();
		nameText.setEditable(false);
		nameText.setBounds(180, 85, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		creditText = new JTextField();
		creditText.setEditable(false);
		creditText.setBounds(180, 133, 86, 24);
		contentPane.add(creditText);
		creditText.setColumns(10);
		
		rankText = new JTextField();
		rankText.setEditable(false);
		rankText.setBounds(180, 175, 86, 24);
		contentPane.add(rankText);
		rankText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(307, 257, 113, 27);
		contentPane.add(save);
		save.addActionListener(this);
	}
	
	public void setId(int a ){
		this.id = a;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			this.dispose();;
		}
	}
	
	public void getInfo() throws Exception{
		DbUtil db = new DbUtil();
		Statement statement = db.getCon().createStatement();
		String sql = "select * from VIP where id='"+id+"'";

		ResultSet rs = statement.executeQuery(sql);
		if(rs.next()){
			IdText.setText(rs.getString("id"));
			nameText.setText(rs.getString("name"));
			creditText.setText(String.valueOf(rs.getInt("score")));
			rankText.setText(String.valueOf(rs.getInt("rank")));	
			this.setVisible(true);
		}
		else{
			JOptionPane.showMessageDialog(null, "�û�������", "����",JOptionPane.WARNING_MESSAGE); 
		}

		rs.close();
		db.getCon().close();
		
	}

}
