package view;

import java.awt.EventQueue;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import utils.Data;
import utils.string;
import dao.Goodsdao;
import entity.Goods;
import entity.User;

public class Payment extends JFrame {

	private JPanel contentPane;
	private JTextField goodsid;
	private JTextField goodsnumber;
	private Data data=new Data();
	private Goodsdao goodsdao=new Goodsdao();
	private JTable GoodsTypeTable;
	private User currentUser;
	private int sum_price=0;
	private JLabel lblNewLabel_3 = new JLabel();
	private JRadioButton judge = new JRadioButton("\u987E\u5BA2\u662F\u5426\u4F1A\u5458");
	private Goods currentgoods=new Goods();

	public Payment() {
		super();
		setResizable(false);
		setTitle("\u6536\u94F6\u53F0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 888, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		lblNewLabel.setBounds(45, 66, 80, 29);
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		goodsid = new JTextField();
		goodsid.setBounds(143, 69, 144, 27);
		goodsid.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u6570  \u91CF\uFF1A");
		lblNewLabel_1.setBounds(349, 66, 68, 29);
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		goodsnumber = new JTextField();
		goodsnumber.setBounds(421, 69, 144, 27);
		goodsnumber.setColumns(10);
		
		JButton btnNewButton = new JButton("\u6DFB \u52A0");
		btnNewButton.setBounds(619, 66, 102, 28);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					goodspayment(e);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JScrollPane goodstabel = new JScrollPane();
		goodstabel.setBounds(23, 124, 826, 210);
		
		JLabel lblNewLabel_2 = new JLabel("\u6536\u94F6\u5458:");
		lblNewLabel_2.setBounds(45, 23, 80, 25);
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_2_1 = new JLabel(currentUser.getName());
		lblNewLabel_2_1.setBounds(131, 23, 80, 25);
		lblNewLabel_2_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JButton btnNewButton_1 = new JButton("\u603B \u8BA1");
		btnNewButton_1.setBounds(747, 66, 102, 28);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JLabel lblNewLabel_3 = new JLabel("\u5546\u54C1\u603B\u8BA1:");
				lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
				lblNewLabel_3.setBounds(171, 360, 168, 44);
				contentPane.add(lblNewLabel_3);
			}
		});
		btnNewButton_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		GoodsTypeTable = new JTable();
		GoodsTypeTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5546\u54C1\u7F16\u53F7", "\u5546\u54C1\u540D\u79F0", "\u5546\u54C1\u5355\u4EF7", "\u5546\u54C1\u6570\u91CF", "\u6B64\u7C7B\u5546\u54C1\u603B\u8BA1"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		GoodsTypeTable.getColumnModel().getColumn(0).setPreferredWidth(116);
		GoodsTypeTable.getColumnModel().getColumn(1).setPreferredWidth(108);
		GoodsTypeTable.getColumnModel().getColumn(2).setPreferredWidth(122);
		GoodsTypeTable.getColumnModel().getColumn(3).setPreferredWidth(130);
		GoodsTypeTable.getColumnModel().getColumn(4).setPreferredWidth(141);
		goodstabel.setViewportView(GoodsTypeTable);
		contentPane.setLayout(null);
		contentPane.add(lblNewLabel_2);
		contentPane.add(lblNewLabel);
		contentPane.add(goodsid);
		contentPane.add(lblNewLabel_1);
		contentPane.add(goodsnumber);
		contentPane.add(btnNewButton);
		contentPane.add(btnNewButton_1);
		contentPane.add(lblNewLabel_2_1);
		contentPane.add(goodstabel);
		
		JLabel lblNewLabel_3 = new JLabel("\u5546\u54C1\u603B\u8BA1:");
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(171, 360, 168, 44);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton_2 = new JButton("\u7ED3 \u8D26");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pay(e);
			}
		});
		btnNewButton_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		btnNewButton_2.setBounds(687, 365, 122, 38);
		contentPane.add(btnNewButton_2);
		
		judge.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		judge.setBounds(508, 372, 144, 25);
		contentPane.add(judge);
		
		JButton btnNewButton_3 = new JButton("\u9000 \u8D27");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Goodsback goodsback=new Goodsback(currentUser);
				goodsback.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		btnNewButton_3.setBounds(628, 10, 208, 29);
		contentPane.add(btnNewButton_3);
		
		this.setLocationRelativeTo(null);                      //���þ���
	}
	
	public Payment(User user) {
		super();
		this.currentUser=user;
		
		setResizable(false);
		setTitle("\u6536\u94F6\u53F0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 888, 469);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u7F16\u53F7\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		goodsid = new JTextField();
		goodsid.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("\u6570  \u91CF\uFF1A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		goodsnumber = new JTextField();
		goodsnumber.setColumns(10);
		
		JButton btnNewButton = new JButton("\u6DFB \u52A0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					goodspayment(e);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JScrollPane goodstabel = new JScrollPane();
		
		JLabel lblNewLabel_2 = new JLabel("\u6536\u94F6\u5458:");
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_2_1 = new JLabel(currentUser.getName());
		lblNewLabel_2_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JButton btnNewButton_1 = new JButton("\u603B \u8BA1");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getsum(e);
			}
		});
		btnNewButton_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addGap(40)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
								.addComponent(lblNewLabel_2, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(18)
									.addComponent(goodsid, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE)
									.addGap(62)
									.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(goodsnumber, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE)
									.addGap(54)
									.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
									.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 102, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.RELATED, 668, Short.MAX_VALUE))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addComponent(goodstabel)))
					.addGap(30))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2_1, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
						.addComponent(goodsid, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
						.addComponent(goodsnumber, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(28)
					.addComponent(goodstabel, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE)
					.addGap(102))
		);
		
		GoodsTypeTable = new JTable();
		GoodsTypeTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5546\u54C1\u7F16\u53F7", "\u5546\u54C1\u540D\u79F0", "\u5546\u54C1\u5355\u4EF7", "\u5546\u54C1\u6570\u91CF", "\u6B64\u7C7B\u5546\u54C1\u603B\u8BA1"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		GoodsTypeTable.getColumnModel().getColumn(0).setPreferredWidth(116);
		GoodsTypeTable.getColumnModel().getColumn(1).setPreferredWidth(108);
		GoodsTypeTable.getColumnModel().getColumn(2).setPreferredWidth(122);
		GoodsTypeTable.getColumnModel().getColumn(3).setPreferredWidth(130);
		GoodsTypeTable.getColumnModel().getColumn(4).setPreferredWidth(141);
		goodstabel.setViewportView(GoodsTypeTable);
		contentPane.setLayout(gl_contentPane);
		
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(171, 360, 168, 44);
		
		JButton btnNewButton_2 = new JButton("\u7ED3 \u8D26");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pay(e);
			}
		});
		btnNewButton_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		btnNewButton_2.setBounds(687, 365, 122, 38);
		contentPane.add(btnNewButton_2);
		
		judge.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		judge.setBounds(508, 372, 144, 25);
		contentPane.add(judge);
		
		JButton btnNewButton_3 = new JButton("\u9000 \u8D27");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Goodsback goodsback=new Goodsback(currentUser);
				goodsback.setVisible(true);
			}
		});
		btnNewButton_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		btnNewButton_3.setBounds(628, 10, 208, 29);
		contentPane.add(btnNewButton_3);
		
		this.setLocationRelativeTo(null);                      //���þ���	
	}

	private void pay(ActionEvent evt) {
		Connection con=null;
		try {
			con=data.getCon();
			int repertory=currentgoods.getRepertory();
			int sale=currentgoods.getSale();
			String goodsid=this.goodsid.getText();
			String goodsnumber=this.goodsnumber.getText();
			if(string.isEmpty(goodsid)) {
				JOptionPane.showMessageDialog(null, "��Ʒ������Ϊ�գ�");
				return;
			}
			
			if(string.isEmpty(goodsnumber)) {
				JOptionPane.showMessageDialog(null, "��������Ϊ�գ�");
				return;
			}
			int number=Integer.parseInt(goodsnumber);
			int ID=Integer.parseInt(goodsid);
			
			sale=sale+number;
			repertory=repertory-number;
			
			String sql1="update goods set repertory= '"+repertory+"',sale= '"+sale+"' where id= '"+ID+"'";
			Statement statement1 = con.createStatement();
			statement1.execute(sql1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(judge.isSelected())
		{
			String phone = JOptionPane.showInputDialog("������˿��ֻ��ţ�");
			if(phone==null){return;}
			if(phone.equals("")){
				JOptionPane.showMessageDialog(null, "������벻��Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			    return;
			}
			String sql2="select * from vip where phone=?";
			PreparedStatement pstmt;
			try {
				pstmt = con.prepareStatement(sql2);
				pstmt.setString(1,phone);
				ResultSet rs=pstmt.executeQuery();
				
				if(rs.next()) {
					int score=0;
					int rank=0;
					score=rs.getInt("score")+sum_price*10;
					rank=getrank(score);
					sql2="update vip set score= '"+score+"',rank= '"+rank+"' where phone= '"+phone+"'";
					Statement statement2 = con.createStatement();
					statement2.execute(sql2);
					this.goodsid.setText("");
					this.goodsnumber.setText("");
					DefaultTableModel dtm=(DefaultTableModel)GoodsTypeTable.getModel();
					lblNewLabel_3.setText(" ");
					dtm.setRowCount(0);
					try {
						con.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}else{
					JOptionPane.showMessageDialog(null, "�ֻ����벻���ڣ�", "����",JOptionPane.WARNING_MESSAGE);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		else
		{
			if(sum_price>100)
			{
				int n = JOptionPane.showConfirmDialog(null, "�˿ʹ˴����ѻ���Ϊ:"+sum_price*10+",�ȼ�Ϊ��"+getrank(10*sum_price)+"��ѯ���Ƿ�ע���Ա?", "��ʾ",JOptionPane.YES_NO_OPTION);//i=0/1  
				if(n==0){	
					Add_vip add = new Add_vip();
				}
			}
			this.goodsid.setText("");
			this.goodsnumber.setText("");
			DefaultTableModel dtm=(DefaultTableModel)GoodsTypeTable.getModel();
			lblNewLabel_3.setText(" ");
			dtm.setRowCount(0);
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	private int getrank(int score) {
		int rank = 0;
		if(score>1000&&score<=2000)
			rank = 1;
		else if(score>2000&&score<=3000)
			rank = 2;
		else if(score>3000&&score<=4000)
			rank = 3;
		else if(score>4000&&score<=5000)
			rank = 4;
		else if(score>5000)
			rank = 5;
		
		return rank;
	}

	
	private void fillTable(Goods goods){
		DefaultTableModel dtm=(DefaultTableModel)GoodsTypeTable.getModel();	
		//dtm.setRowCount(0);
		Connection con =null;
		try {
			con=data.getCon();
			Vector v=new Vector();
			v.add(goods.getGoodsID());
			v.add(goods.getGoodsName());
			v.add(goods.getPrice());
			v.add(goods.getNumber());
			int sumprice=goods.getNumber()*goods.getPrice();
			v.add(sumprice);
			dtm.addRow(v);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				data.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	private void getsum(ActionEvent evt) {
		DefaultTableModel dtm=(DefaultTableModel)GoodsTypeTable.getModel();
		sum_price=0;
		for (int row =0; row < dtm.getRowCount(); row++) {
			Object good_sprice=dtm.getValueAt(row, 4);
			int price=0;
			price=Integer.parseInt("" + good_sprice);
			sum_price=sum_price+price;
		}
		lblNewLabel_3.setText("\u5546\u54C1\u603B\u8BA1:"+sum_price);
		contentPane.add(lblNewLabel_3);
		contentPane.repaint();
	}
	
	@SuppressWarnings("unused")
	private void goodspayment(ActionEvent evt) throws SQLException, Exception {
		String goodsid=this.goodsid.getText();
		String goodsnumber=this.goodsnumber.getText();
		if(string.isEmpty(goodsid)) {
			JOptionPane.showMessageDialog(null, "��Ʒ������Ϊ�գ�");
			return;
		}
		
		if(string.isEmpty(goodsnumber)) {
			JOptionPane.showMessageDialog(null, "��������Ϊ�գ�");
			return;
		}
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		String strsql = "select * from goods where id ='"+goodsid+"'";
		ResultSet rs = statement.executeQuery(strsql);
		if(rs.next()){
			if(rs.getInt("repertory")<=0){
				JOptionPane.showMessageDialog(null, "����Ʒ�ۿգ�");
				db.getCon().close();
			}else{
				int number=Integer.parseInt(goodsnumber);
				int ID=Integer.parseInt(goodsid);
				
				Goods goods=new Goods(ID,number);
				Connection con=null;
				try {
					con=data.getCon();
					currentgoods=goodsdao.login(con,goods);
					if(currentgoods!=null){
						currentgoods.setNumber(number);
						this.fillTable(currentgoods);
					}
					else {
						JOptionPane.showMessageDialog(null, "��Ʒ��Ŵ���");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}finally {
					try {
						data.closeCon(con);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}else{
			JOptionPane.showMessageDialog(null, "��Ʒ��Ŵ���");
		}
		
	}
}
