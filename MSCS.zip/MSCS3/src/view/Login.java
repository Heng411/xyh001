package view;

import java.awt.EventQueue;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import utils.Data;
import utils.string;
import entity.User;
import dao.Userdao;


public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField username;
	private JPasswordField userpassword;
	private Data data=new Data();
	private Userdao userdao=new Userdao();
	private User currentUser;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setResizable(false);
		setTitle("MSCS\u7BA1\u7406\u7CFB\u7EDF");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 555, 483);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("MSCS\u767B\u5F55\u754C\u9762");
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 27));
		
		JLabel lblNewLabel_1 = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_2 = new JLabel("\u5BC6\u7801\uFF1A");
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		username = new JTextField();
		username.setColumns(10);
		
		userpassword = new JPasswordField();
		
		JButton btnNewButton = new JButton("\u767B\u5F55");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userlogon(e);
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JButton btnNewButton_1 = new JButton("\u91CD\u7F6E");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reset(e);
			}
		});
		btnNewButton_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(173)
					.addComponent(lblNewLabel)
					.addContainerGap(181, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addGap(142)
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
							.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(11))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(131)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_1)
								.addComponent(lblNewLabel_2))
							.addPreferredGap(ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(userpassword, 176, 176, 176)
								.addComponent(username, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 176, GroupLayout.PREFERRED_SIZE))))
					.addGap(143))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(51)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE)
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(username, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
						.addComponent(lblNewLabel_1, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
						.addComponent(userpassword, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(61)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))
					.addGap(115))
		);
		contentPane.setLayout(gl_contentPane);
		this.setLocationRelativeTo(null);                      //���þ���	
	}
/*��½*/
	private void userlogon(ActionEvent evt) {
		String username=this.username.getText();
		String password=new String(this.userpassword.getPassword());
		if(string.isEmpty(username)) {
			JOptionPane.showMessageDialog(null, "�û�������Ϊ�գ�");
			return;
		}
		
		if(string.isEmpty(password)) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ�գ�");
			return;
		}
		
		User user=new User(username,password);
		Connection con=null;
		try {
			con=data.getCon();
			currentUser=userdao.login(con,user);
			if(currentUser!=null){
				if(currentUser.getPosition().equals("����Ա")) {
					dispose();
					Payment payment=new Payment(currentUser);
					payment.setVisible(true);
				}
				else if(currentUser.getPosition().equals("�ͻ�����")) {
					dispose();
					Choice choice1=new Choice(currentUser);
					choice1.setVisible(true);
				}
				else if(currentUser.getPosition().equals("�ܾ���")) {
					dispose();
					Choice choice2=new Choice(currentUser);
					choice2.setVisible(true);
				}
				else if(currentUser.getPosition().equals("ϵͳ����Ա")) {
					dispose();
					Choice choice3=new Choice(currentUser);
					choice3.setVisible(true);
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "�û����������");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				data.closeCon(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
/*����*/
	private void reset(ActionEvent evt) {
		this.username.setText("");
		this.userpassword.setText("");
	}

}
