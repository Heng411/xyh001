package view;

import javax.swing.JFrame;


import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

import utils.Data;
import utils.string;

public class VipAdd extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField nameText;
	private JTextField creditText;
	private JTextField rankText;
	private JButton save;
	private JLabel label;
	private JTextField phoneText;
	private VipMana mana;
	
	public VipAdd(VipMana mana) {
		this.mana = mana;
		setResizable(false);
		setTitle("��Ա����");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 452, 362);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel namelabel = new JLabel("����");
		namelabel.setBounds(119, 43, 65, 24);
		contentPane.add(namelabel);
		
		JLabel creditLabel = new JLabel("����");
		creditLabel.setBounds(123, 92, 72, 18);
		contentPane.add(creditLabel);
		
		JLabel rankLabel = new JLabel("�ȼ�");
		rankLabel.setBounds(123, 133, 72, 18);
		contentPane.add(rankLabel);
		
		nameText = new JTextField();
		nameText.setBounds(219, 46, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		creditText = new JTextField();
		creditText.setBounds(219, 89, 86, 24);
		contentPane.add(creditText);
		creditText.setColumns(10);
		
		rankText = new JTextField();
		rankText.setBounds(219, 126, 86, 24);
		contentPane.add(rankText);
		rankText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.addActionListener(this);
		save.setBounds(296, 221, 113, 27);
		contentPane.add(save);
		
		label = new JLabel("�ֻ���");
		label.setBounds(123, 164, 72, 18);
		contentPane.add(label);
		
		phoneText = new JTextField();
		phoneText.setBounds(219, 163, 86, 24);
		contentPane.add(phoneText);
		phoneText.setColumns(10);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			String name = nameText.getText();
			String phone =  phoneText.getText(); 
			try {
				Data db = new Data();
				Statement statement = db.getCon().createStatement();
				String strsql = "select * from vip where  phone='"+phone+"'";
				ResultSet rs = statement.executeQuery(strsql);
				if(string.isEmpty(name)||string.isEmpty(phone)||string.isEmpty(creditText.getText())||string.isEmpty(rankText.getText())){
					JOptionPane.showMessageDialog(null, "������Ϣ����Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
				}else if(rs.next()){
					JOptionPane.showMessageDialog(null, "��Ա�Ѵ���", "����",JOptionPane.WARNING_MESSAGE);
				}else{
					int credit = Integer.parseInt(creditText.getText());
					int rank = Integer.parseInt(rankText.getText());
					String sql = "insert into vip(name,score,rank,phone) values ('"+name+"','"+credit+"','"+rank+"','"+phone+"')";
					statement.execute(sql);
					db.getCon().close();
					this.dispose();
					mana.refresh();
				}	
				} catch (ClassNotFoundException ee) {
					// ���ݿ��������쳣����
					System.out.println("Sorry,can`t find the Driver!");
					ee.printStackTrace();
				} catch (SQLException ee) {
					// ���ݿ�����ʧ���쳣����
					ee.printStackTrace();
				} catch (Exception ee) {
					// TODO: handle exception
					ee.printStackTrace();
				}
			

		}
			
	}
}
