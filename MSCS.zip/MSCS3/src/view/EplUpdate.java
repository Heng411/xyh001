package view;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import utils.Data;
import utils.string;

public class EplUpdate extends JFrame implements ActionListener{

	private JPanel contentPane;
	private int temp;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField priceText;
	private JButton save;
	private JLabel indateLabel;
	private JTextField indateText;
	private EplMana mana;
	private JLabel phoneLabel;
	private JTextField phoneText;
	private JLabel lblNewLabel;
	private JTextField textField;
	private JComboBox comboBox;
	
	public EplUpdate(EplMana mana) {
		this.mana = mana;
		setResizable(false);
		setTitle("Ա���޸�");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 456, 496);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("ID");
		idLabel.setBounds(119, 29, 72, 18);
		contentPane.add(idLabel);
		
		IdText = new JTextField();
		IdText.setEditable(false);
		IdText.setBounds(217, 26, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(119, 77, 72, 18);
		contentPane.add(nameLabel);
		
		nameText = new JTextField();
		nameText.setBounds(217, 74, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		JLabel posLabel = new JLabel("ְλ");
		posLabel.setBounds(119, 130, 72, 18);
		contentPane.add(posLabel);
		
		JLabel salaryLabel = new JLabel("н��");
		salaryLabel.setBounds(119, 190, 72, 18);
		contentPane.add(salaryLabel);
		
		priceText = new JTextField();
		priceText.setBounds(217, 187, 86, 24);
		contentPane.add(priceText);
		priceText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(325, 409, 113, 27);
		contentPane.add(save);
		save.addActionListener(this);
		
		indateLabel = new JLabel("��ְ����");
		indateLabel.setBounds(119, 247, 72, 18);
		contentPane.add(indateLabel);
		
		indateText = new JTextField();
		indateText.setBounds(217, 244, 86, 24);
		contentPane.add(indateText);
		indateText.setColumns(10);
		
		phoneLabel = new JLabel("�ֻ���");
		phoneLabel.setBounds(119, 354, 72, 18);
		contentPane.add(phoneLabel);
		
		phoneText = new JTextField();
		phoneText.setText("");
		phoneText.setBounds(217, 351, 86, 24);
		contentPane.add(phoneText);
		phoneText.setColumns(10);
		
		lblNewLabel = new JLabel("״̬");
		lblNewLabel.setBounds(119, 308, 72, 18);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(217, 305, 86, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		String[] position = {"����Ա","�ͻ�����","�ܾ���","ϵͳ����Ա"};
		comboBox = new JComboBox(position);
		comboBox.setBounds(217, 126, 86, 27);
		
		contentPane.add(comboBox);
		
	}
	public void setTemp(int i){
		this.temp = i;
	}
	public void setTable(JTable table){
		//{"���","����","ְλ","н��","��ְʱ��","״̬","�ֻ���"};
		IdText.setText(table.getValueAt(temp, 0).toString());
		nameText.setText(table.getValueAt(temp, 1).toString());
		//posText.setText(table.getValueAt(temp, 2).toString());
		priceText.setText(table.getValueAt(temp, 3).toString());
		indateText.setText(table.getValueAt(temp, 4).toString());
		textField.setText(table.getValueAt(temp, 5).toString());
		phoneText.setText(table.getValueAt(temp, 6).toString());
	}
	//ϵͳ����Ա
	public void setTable2(JTable table){
		IdText.setText(table.getValueAt(temp, 0).toString());
		nameText.setText(table.getValueAt(temp, 1).toString());
		priceText.setText(table.getValueAt(temp, 4).toString());
		indateText.setText(table.getValueAt(temp, 5).toString());
		textField.setText(table.getValueAt(temp, 6).toString());
		phoneText.setText(table.getValueAt(temp, 7).toString());
	}

	public void actionPerformed(ActionEvent e) {
        String id = IdText.getText();
		String name = nameText.getText();
		String position = comboBox.getSelectedItem().toString();
		float salary = Float.parseFloat(priceText.getText());
		String indate = indateText.getText();
		String phone =phoneText.getText();
		try {	
			Data db = new Data();
			Statement statement = db.getCon().createStatement();
			String strsql = "select * from employee where  phone not in ('"+phone+"') and phone ='"+phone+"'";
			ResultSet rs = statement.executeQuery(strsql);
			if(string.isEmpty(name) ||  string.isEmpty(priceText.getText()) || string.isEmpty(indateText.getText()) || string.isEmpty(phone)){
				JOptionPane.showMessageDialog(null, "������Ϣ����Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			}else if(rs.next()){
				JOptionPane.showMessageDialog(null, "�ֻ������Ѵ���", "����",JOptionPane.WARNING_MESSAGE);
			}
			else{
				String sql = "update employee set name= '"+name+"',position='"+position+"',salary='"+salary+"',indate='"+indate+"',phone = '"+phone+"' where id= '"+id+"'";
				statement.execute(sql);
				db.getCon().close();
				this.dispose();
				mana.refresh();
			}
			} catch (ClassNotFoundException ee) {
					ee.printStackTrace();
				} catch (SQLException ee) {
					ee.printStackTrace();
				} catch (Exception ee) {
					ee.printStackTrace();
				}
			
	
	}
	
}
