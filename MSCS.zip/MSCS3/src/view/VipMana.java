package view;

import java.awt.Color;


import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import utils.Data;
import entity.User;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class VipMana extends JFrame implements ActionListener {

	private JPanel contentPane;
	private JTable infoTable;
	private Vector<Object> ve; 
	private JButton add ;
	private JButton update;
	private JButton delete;
	private JButton search;
	private JButton refresh;
	private int DelID;
	private JButton Return;
	private User currentUser;

	public VipMana(User user)  {
		this.currentUser = user;
		
		setResizable(false);
		setTitle("��Ա����");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 712, 474);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel showInfo = new JPanel();
		showInfo.setBounds(0, 46, 694, 381);
		contentPane.add(showInfo);
		showInfo.setLayout(null);
		
		String[] columnNames = {"���","����","����","�ȼ�","�ֻ���"};
		Object[][] rowDatas = {};
		
		DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
		infoTable = new JTable(myModel);
		infoTable.setBounds(39, 13, 586, 322);
		
		try {
			getInfo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// ���ñ���������ɫ
		infoTable.setForeground(Color.BLACK);                   // ������ɫ
		infoTable.setFont(new Font(null, Font.PLAIN, 14));      // ������ʽ
		infoTable.setSelectionForeground(Color.DARK_GRAY);      // ѡ�к�������ɫ
		infoTable.setSelectionBackground(Color.LIGHT_GRAY);     // ѡ�к����屳��
		infoTable.setGridColor(Color.GRAY);                     // ������ɫ

        // ���ñ�ͷ
		infoTable.getTableHeader().setFont(new Font(null, Font.BOLD, 14));  // ���ñ�ͷ����������ʽ
		infoTable.getTableHeader().setForeground(Color.RED);                // ���ñ�ͷ����������ɫ
		infoTable.getTableHeader().setResizingAllowed(false);               // ���ò������ֶ��ı��п�
		infoTable.getTableHeader().setReorderingAllowed(false);             // ���ò������϶������������
		 // �����и�
		infoTable.setRowHeight(30);
		
		JScrollPane scrollPane = new JScrollPane(infoTable);
		scrollPane.setBounds(0, 13, 694, 343);
		showInfo.add(scrollPane);
		
		JPanel function = new JPanel();
		function.setBounds(0, 0, 694, 47);
		contentPane.add(function);
		
		add = new JButton("����");
		add.setBounds(14, 0, 89, 34);
		add.addActionListener(this); 
		
		function.setLayout(null);
		function.add(add);
		
		update = new JButton("�޸�");
		update.setBounds(131, 0, 81, 34);
		update.addActionListener(this);
		function.add(update);
		
		delete = new JButton("ɾ��");
		delete.setBounds(237, 0, 81, 34);
		delete.addActionListener(this);
		function.add(delete);
		
		search = new JButton("����");
		search.setBounds(352, 0, 81, 34);
		search.addActionListener(this);
		function.add(search);
		
		refresh = new JButton("ˢ��");
		refresh.addActionListener(this);
		refresh.setBounds(476, 2, 81, 31);
		function.add(refresh);
		
		Return = new JButton("����");
		Return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Choice choice=new Choice(currentUser);
				choice.setVisible(true);
			}
		});
		Return.setBounds(592, 2, 81, 31);
		function.add(Return);
}
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(add)){
			VipAdd vipadd = new VipAdd(this);
			
		}
		if(e.getSource().equals(refresh)){
			refresh();
		}
		if(e.getSource().equals(delete)){
			int del = infoTable.getSelectedRow();
			if(del == -1){
				JOptionPane.showMessageDialog(null, "δѡ��ɾ����¼", "����",JOptionPane.WARNING_MESSAGE);
			}else{
				DelID = Integer.parseInt(infoTable.getValueAt(del, 0).toString());
				int n = JOptionPane.showConfirmDialog(null, "�Ƿ�ȷ��ɾ��?", "��Աɾ��",JOptionPane.YES_NO_OPTION);//i=0/1  
				if(n==0){	
					try {
						delInfo();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
				refresh();
				
			}
			
		}
		if(e.getSource().equals(update)){
			int row = infoTable.getSelectedRow();
			if(row==-1){
				JOptionPane.showMessageDialog(null, "δѡ����¼�¼", "����",JOptionPane.WARNING_MESSAGE);
			}else{
				VipUpdate alter = new VipUpdate(this);
				alter.setTemp(row);
				alter.setVisible(true);
				alter.setTable(infoTable);
			}
			
		}
		if(e.getSource().equals(search)){
			String id = JOptionPane.showInputDialog("�������Ա��ţ�");
			if(id==null){return;}
			if(id.equals("")){
				JOptionPane.showMessageDialog(null, "�����Ų���Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			    return;
			}
			Vipsearch sea = new Vipsearch();
			sea.setId(Integer.parseInt(id));
			try {
				sea.getInfo();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			
		}
	}

	public void getInfo()throws Exception{
		String[] columnNames = {"���","����","����","�ȼ�","�ֻ���"};
		Object[][] rowDatas = {};
		
		DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
		infoTable = new JTable(myModel);
		
		Data db = new Data();
		Statement statement = 	db.getCon().createStatement();
		String sql = "select * from VIP";

		ResultSet rs = statement.executeQuery(sql);
		
		while (rs.next()) {
			ve = new Vector<Object>();
			ve.addElement(rs.getString("id")); 
			ve.addElement(rs.getString("name"));
			ve.addElement(rs.getInt("score"));
			ve.addElement(rs.getInt("rank"));
			ve.addElement(rs.getString("phone"));
			myModel.addRow(ve);
		}
		rs.close();
		db.getCon().close();
	}
	
	public void delInfo() throws Exception{
	
		Data db = new Data();
		Statement statement = 	db.getCon().createStatement();
		String sql = "delete from vip where id = '"+DelID+"'";
		statement.execute(sql);
		db.getCon().close();
		
	}
	public void refresh(){
		this.dispose();
		VipMana vw = new VipMana(currentUser);
		vw.setVisible(true);
	}
}

