package view;

import java.awt.BorderLayout;


import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import utils.Data;
import utils.string;
import javax.swing.JComboBox;

public class EplAdd extends JFrame implements ActionListener {
	
	private JPanel contentPane;
	private JTextField nameText;
	private JTextField PriceText;
	private JButton save;
	private JTextField InText;
	private EplMana mana;
	private JLabel label;
	private JTextField textField;
	private JLabel idLabel;
	private JTextField idText;
	private JComboBox comboBox;
	private JTextField pwdText;
	
	public EplAdd(EplMana mana) {
		this.mana = mana;
		
		setTitle("��Ա����");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 452, 425);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel namelabel = new JLabel("����");
		namelabel.setBounds(123, 70, 61, 18);
		contentPane.add(namelabel);
		
		JLabel PosLabel = new JLabel("ְλ");
		PosLabel.setBounds(123, 140, 72, 18);
		contentPane.add(PosLabel);
		
		JLabel PriceLabel = new JLabel("н��");
		PriceLabel.setBounds(123, 179, 72, 18);
		contentPane.add(PriceLabel);
		
		nameText = new JTextField();
		nameText.setBounds(219, 67, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		PriceText = new JTextField();
		PriceText.setBounds(219, 176, 86, 24);
		contentPane.add(PriceText);
		PriceText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.addActionListener(this);
		save.setBounds(307, 338, 113, 27);
		contentPane.add(save);
		
		JLabel InLabel = new JLabel("��ְ����");
		InLabel.setBounds(123, 219, 72, 18);
		contentPane.add(InLabel);
		
		InText = new JTextField();
		InText.setBounds(219, 213, 86, 24);
		contentPane.add(InText);
		InText.setColumns(10);
		
		label = new JLabel("�ֻ���");
		label.setBounds(123, 264, 72, 18);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setBounds(219, 261, 86, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
		idLabel = new JLabel("ID");
		idLabel.setBounds(123, 26, 72, 18);
		contentPane.add(idLabel);
		
		idText = new JTextField();
		idText.setBounds(219, 23, 86, 24);
		contentPane.add(idText);
		idText.setColumns(10);
		
		String[] position = {"����Ա","�ͻ�����","�ܾ���","ϵͳ����Ա"};
		comboBox = new JComboBox(position);
		comboBox.setBounds(219, 136, 86, 27);
		
		contentPane.add(comboBox);
		
		JLabel passLabel = new JLabel("\u5BC6\u7801");
		passLabel.setBounds(123, 109, 72, 18);
		contentPane.add(passLabel);
		
		pwdText = new JTextField();
		pwdText.setBounds(219, 104, 86, 24);
		contentPane.add(pwdText);
		pwdText.setColumns(10);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			String id= idText.getText();
			String name = nameText.getText();
			String pwd = pwdText.getText();
			String phone =textField.getText();
			try {	
				Data db = new Data();
				Statement statement = db.getCon().createStatement();
				String strsql = "select * from employee where  phone='"+phone+"'";
				ResultSet rs = statement.executeQuery(strsql);
				if(string.isEmpty(id)||string.isEmpty(pwd) ||string.isEmpty(name)||  string.isEmpty(PriceText.getText()) || string.isEmpty(InText.getText()) || string.isEmpty(phone)){
					JOptionPane.showMessageDialog(null, "������Ϣ����Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
				}
				else if(rs.next()){
					JOptionPane.showMessageDialog(null, "�ֻ������Ѵ���", "����",JOptionPane.WARNING_MESSAGE);
				
				}else{
					String strsql2 = "select * from employee where  id='"+id+"'";
					ResultSet rs2 = statement.executeQuery(strsql2);
					if(rs2.next()){
						JOptionPane.showMessageDialog(null, "ID�Ѵ���", "����",JOptionPane.WARNING_MESSAGE);
					}
					else{
						String position = comboBox.getSelectedItem().toString();
						String indate = InText.getText();
						String state = "��ְ";
						float price = Float.parseFloat(PriceText.getText());//'"+id+"','"+name+"','"+position+"','"+pwd+"',"+price+"','"+indate+"','"+phone+"','"+state+"'
						String sql = "insert into employee(id,name,position,id_key,salary,indate,phone,state) values ('"+id+"','"+name+"','"+position+"','"+pwd+"','"+price+"','"+indate+"','"+phone+"','"+state+"')";
						statement.execute(sql);
						db.getCon().close();
						this.dispose();
						mana.refresh();
					}
				}
				
			} catch (ClassNotFoundException ee) {
					
					System.out.println("Sorry,can`t find the Driver!");
					ee.printStackTrace();
			} catch (SQLException ee) {
			
					ee.printStackTrace();
			} catch (Exception ee) {

					ee.printStackTrace();
			}

		}
			
	}
}
