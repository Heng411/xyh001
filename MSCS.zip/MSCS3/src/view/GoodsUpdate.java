package view;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import utils.Data;
import utils.string;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JButton;

public class GoodsUpdate extends JFrame implements ActionListener{

	private JPanel contentPane;
	private int temp;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField repText;
	private JTextField priceText;
	private JButton save;
	private JLabel saleLabel;
	private JTextField saleText;
	private GoodsMana mana;
	public GoodsUpdate(GoodsMana mana) {
		setResizable(false);
		this.mana = mana;
		setTitle("��Ʒ�޸�");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 457, 434);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("ID");
		idLabel.setBounds(72, 66, 72, 18);
		contentPane.add(idLabel);
		
		IdText = new JTextField();
		IdText.setEditable(false);
		IdText.setBounds(169, 63, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(72, 126, 72, 18);
		contentPane.add(nameLabel);
		
		nameText = new JTextField();
		nameText.setBounds(169, 123, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		JLabel RepLabel = new JLabel("�����");
		RepLabel.setBounds(72, 178, 72, 18);
		contentPane.add(RepLabel);
		
		repText = new JTextField();
		repText.setBounds(169, 175, 86, 24);
		contentPane.add(repText);
		repText.setColumns(10);
		
		JLabel rankLabel = new JLabel("�۸�");
		rankLabel.setBounds(72, 228, 72, 18);
		contentPane.add(rankLabel);
		
		priceText = new JTextField();
		priceText.setBounds(169, 225, 86, 24);
		contentPane.add(priceText);
		priceText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(312, 330, 113, 27);
		contentPane.add(save);
		save.addActionListener(this);
		
		saleLabel = new JLabel("���۳�");
		saleLabel.setBounds(72, 276, 72, 18);
		contentPane.add(saleLabel);
		
		saleText = new JTextField();
		saleText.setBounds(169, 273, 86, 24);
		contentPane.add(saleText);
		saleText.setColumns(10);
		
	}
	public void setTemp(int i){
		this.temp = i;
	}
	public void setTable(JTable table){
	
		IdText.setText(table.getValueAt(temp, 0).toString());
		nameText.setText(table.getValueAt(temp, 1).toString());
		repText.setText(table.getValueAt(temp, 2).toString());
		priceText.setText(table.getValueAt(temp, 3).toString());
		saleText.setText(table.getValueAt(temp, 4).toString());
		
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			int id = Integer.parseInt(IdText.getText());
			String name = nameText.getText();
			int rep = Integer.parseInt(repText.getText());
			int price = Integer.parseInt(priceText.getText());
			int sale = Integer.parseInt(saleText.getText());
			int repertory = Integer.parseInt(repText.getText());
			try {
				if(string.isEmpty(name)|| string.isEmpty(repText.getText()) || string.isEmpty(priceText.getText()) || string.isEmpty(saleText.getText()) ){
					JOptionPane.showMessageDialog(null, "������Ϣ����Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
				}else{
					Data db = new Data();
					Statement statement = db.getCon().createStatement();	
					if(sale>=0 && sale<=200){
						String demand = "С";
						String sql = "update goods set name= '"+name+"',repertory='"+rep+"',price='"+price+"',sale='"+sale+"',demand='"+demand+"' where id= '"+id+"'";
						statement.execute(sql);
					}else if(sale>200 && sale<=500){
						String demand = "��";
						String sql = "update goods set name= '"+name+"',repertory='"+rep+"',price='"+price+"',sale='"+sale+"',demand='"+demand+"' where id= '"+id+"'";
						statement.execute(sql);
					}else if(sale > 500){
						String demand = "��";
						String sql = "update goods set name= '"+name+"',repertory='"+rep+"',price='"+price+"',sale='"+sale+"',demand='"+demand+"' where id= '"+id+"'";
						statement.execute(sql);
					}
					db.getCon().close();
				}
				
				} catch (ClassNotFoundException ee) {
					// ���ݿ��������쳣����
					System.out.println("Sorry,can`t find the Driver!");
					ee.printStackTrace();
				} catch (SQLException ee) {
					// ���ݿ�����ʧ���쳣����
					ee.printStackTrace();
				} catch (Exception ee) {
					ee.printStackTrace();
				}
			this.dispose();
			mana.refresh();
		}
	}
	
	
}
