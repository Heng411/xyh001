package view;

import java.awt.EventQueue;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

import entity.User;
import view.EplMana;
import view.GoodsMana;
import view.VipMana;

public class Choice extends JFrame {

	private JPanel contentPane;
	private User currentUser;

	public Choice() {
		
		setTitle("\u529F\u80FD\u9009\u62E9");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 351);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u804C\u4F4D\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_1 = new JLabel(currentUser.getPosition());
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JButton Good_Button = new JButton("\u5546\u54C1\u7BA1\u7406");
		Good_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				open_goods(e);
			}
		});
		Good_Button.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		
		JButton Vip_Button = new JButton("\u4F1A\u5458\u7BA1\u7406");
		Vip_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				open_vip(e);
			}
		});
		Vip_Button.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		
		JButton Employee_Button = new JButton("\u4EBA\u5458\u7BA1\u7406");
		Employee_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				open_employee(e);
			}
		});
		Employee_Button.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(19)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE))
						.addComponent(Good_Button, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE))
					.addGap(71)
					.addComponent(Vip_Button, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
					.addGap(66)
					.addComponent(Employee_Button, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(125, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(22)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addGap(55)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(Good_Button, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE)
						.addComponent(Vip_Button, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE)
						.addComponent(Employee_Button, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(97, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		if(currentUser.getPosition().equals("�ͻ�����")) {
			Employee_Button.setEnabled(false);
		}
		this.setLocationRelativeTo(null);                      //���þ���
		
	}
	
	protected void open_employee(ActionEvent evt) {
		dispose();
		EplMana eplMana=new EplMana(currentUser);
		eplMana.setVisible(true);
		
	}

	protected void open_vip(ActionEvent evt) {
		dispose();
		VipMana vipMana=new VipMana(currentUser);
		vipMana.setVisible(true);
	}

	private void open_goods(ActionEvent evt) {
		dispose();
		GoodsMana goodsMana=new GoodsMana(currentUser);
		goodsMana.setVisible(true);
	}

	public Choice(User user) {
		super();
		this.currentUser=user;
		
		setTitle("\u529F\u80FD\u9009\u62E9");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 351);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u804C\u4F4D\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_1 = new JLabel(currentUser.getPosition());
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JButton Good_Button = new JButton("\u5546\u54C1\u7BA1\u7406");
		Good_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				open_goods(e);
			}
		});
		Good_Button.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		
		JButton Vip_Button = new JButton("\u4F1A\u5458\u7BA1\u7406");
		Vip_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				open_vip(e);
			}
		});
		Vip_Button.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		
		JButton Employee_Button = new JButton("\u4EBA\u5458\u7BA1\u7406");
		Employee_Button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				open_employee(e);
			}
		});
		Employee_Button.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(19)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 59, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 99, GroupLayout.PREFERRED_SIZE))
						.addComponent(Good_Button, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE))
					.addGap(71)
					.addComponent(Vip_Button, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
					.addGap(66)
					.addComponent(Employee_Button, GroupLayout.PREFERRED_SIZE, 116, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(125, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(22)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addGap(55)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(Good_Button, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE)
						.addComponent(Vip_Button, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE)
						.addComponent(Employee_Button, GroupLayout.PREFERRED_SIZE, 107, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(97, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		if(currentUser.getPosition().equals("�ͻ�����")) {
			Employee_Button.setEnabled(false);
		}
		this.setLocationRelativeTo(null);                      //���þ���
	}
}
