package view;

import java.awt.BorderLayout;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import utils.Data;


public class EplSearch extends JFrame implements ActionListener {

	private JPanel contentPane;
	private String id;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField posText;
	private JTextField priceText;
	private JButton save;
	private JLabel indateLabel;
	private JTextField indateText;
	private EplMana mana;
	private JLabel phoneLabel;
	private JTextField phoneText;
	private JLabel lblNewLabel;
	private JTextField textField;
	public EplSearch(EplMana mana) {
		this.mana = mana;
		setResizable(false);
		setTitle("Ա����ѯ");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 456, 496);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("ID");
		idLabel.setBounds(119, 29, 72, 18);
		contentPane.add(idLabel);
		
		IdText = new JTextField();
		IdText.setEditable(false);
		IdText.setBounds(217, 26, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(119, 77, 72, 18);
		contentPane.add(nameLabel);
		
		nameText = new JTextField();
		nameText.setEditable(false);
		nameText.setBounds(217, 74, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		JLabel posLabel = new JLabel("ְλ");
		posLabel.setBounds(119, 130, 72, 18);
		contentPane.add(posLabel);
		
		posText = new JTextField();
		posText.setEditable(false);
		posText.setBounds(217, 127, 86, 24);
		contentPane.add(posText);
		posText.setColumns(10);
		
		JLabel salaryLabel = new JLabel("н��");
		salaryLabel.setBounds(119, 190, 72, 18);
		contentPane.add(salaryLabel);
		
		priceText = new JTextField();
		priceText.setEditable(false);
		priceText.setBounds(217, 187, 86, 24);
		contentPane.add(priceText);
		priceText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(325, 409, 113, 27);
		contentPane.add(save);
		save.addActionListener(this);
		
		indateLabel = new JLabel("��ְ����");
		indateLabel.setBounds(119, 247, 72, 18);
		contentPane.add(indateLabel);
		
		indateText = new JTextField();
		indateText.setEditable(false);
		indateText.setBounds(217, 244, 86, 24);
		contentPane.add(indateText);
		indateText.setColumns(10);
		
		phoneLabel = new JLabel("�ֻ���");
		phoneLabel.setBounds(119, 354, 72, 18);
		contentPane.add(phoneLabel);
		
		phoneText = new JTextField();
		phoneText.setEditable(false);
		phoneText.setText("");
		phoneText.setBounds(217, 351, 86, 24);
		contentPane.add(phoneText);
		phoneText.setColumns(10);
		
		lblNewLabel = new JLabel("״̬");
		lblNewLabel.setBounds(119, 308, 72, 18);
		contentPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setBounds(217, 305, 86, 24);
		contentPane.add(textField);
		textField.setColumns(10);
		
	}
	public void setId(String a ){
		this.id = a;
	}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			this.dispose();;
		}
	}
	
	public void getInfo() throws Exception{
		
		// ������ѯ�����
	
			
			Data db = new Data();
			Statement statement = db.getCon().createStatement();	
			String sql = "select * from employee where id='"+id+"'";

			ResultSet rs = statement.executeQuery(sql);
			if(rs.next()){
				IdText.setText(rs.getString("id"));
				nameText.setText(rs.getString("name"));
				posText.setText(rs.getString("position"));
				priceText.setText(rs.getString("salary"));
				indateText.setText(rs.getString("indate"));
				textField.setText(rs.getString("state"));
				phoneText.setText(rs.getString("phone"));
				this.setVisible(true);
			}
			else{
				JOptionPane.showMessageDialog(null, "��Ա������", "����",JOptionPane.WARNING_MESSAGE); 
			}

			rs.close();
			db.getCon().close();
		
	}

	

}
