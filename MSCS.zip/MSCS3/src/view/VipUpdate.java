package view;

import java.awt.event.ActionEvent;


import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import utils.Data;
import utils.string;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.JButton;

public class VipUpdate extends JFrame implements ActionListener{

	private JPanel contentPane;
	private int temp;
	private JTextField IdText;
	private JTextField nameText;
	private JTextField creditText;
	private JTextField rankText;
	private JButton save;
	private JTextField phoneText;
	private VipMana mana;
	
	public VipUpdate(VipMana mana) {
		this.mana = mana;
		setTitle("��Ա�޸�");
		this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);//ֻ�رյ�ǰ����
		setBounds(100, 100, 454, 357);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel idLabel = new JLabel("ID");
		idLabel.setBounds(72, 26, 72, 18);
		contentPane.add(idLabel);
		
		IdText = new JTextField();
		IdText.setEditable(false);
		IdText.setBounds(169, 23, 86, 24);
		contentPane.add(IdText);
		IdText.setColumns(10);
		
		JLabel nameLabel = new JLabel("����");
		nameLabel.setBounds(72, 70, 72, 18);
		contentPane.add(nameLabel);
		
		nameText = new JTextField();
		nameText.setBounds(169, 67, 86, 24);
		contentPane.add(nameText);
		nameText.setColumns(10);
		
		JLabel CreditLabel = new JLabel("����");
		CreditLabel.setBounds(72, 119, 72, 18);
		contentPane.add(CreditLabel);
		
		creditText = new JTextField();
		creditText.setBounds(169, 116, 86, 24);
		contentPane.add(creditText);
		creditText.setColumns(10);
		
		JLabel rankLabel = new JLabel("�ȼ�");
		rankLabel.setBounds(72, 163, 72, 18);
		contentPane.add(rankLabel);
		
		rankText = new JTextField();
		rankText.setBounds(169, 153, 86, 24);
		contentPane.add(rankText);
		rankText.setColumns(10);
		
		save = new JButton("ȷ��");
		save.setBounds(309, 270, 113, 27);
		contentPane.add(save);
		
		JLabel phoneLabel = new JLabel("�ֻ���");
		phoneLabel.setBounds(72, 206, 72, 18);
		contentPane.add(phoneLabel);
		
		phoneText = new JTextField();
		phoneText.setBounds(169, 203, 86, 24);
		contentPane.add(phoneText);
		phoneText.setColumns(10);
		save.addActionListener(this);
		
	}
	public void setTemp(int i){
		this.temp = i;
	}
	public void setTable(JTable table){
	
		IdText.setText(table.getValueAt(temp, 0).toString());
		nameText.setText(table.getValueAt(temp, 1).toString());
		creditText.setText(table.getValueAt(temp, 2).toString());
		rankText.setText(table.getValueAt(temp, 3).toString());
		phoneText.setText(table.getValueAt(temp, 4).toString());
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(save)){
			if(string.isEmpty(nameText.getText()) ){
				JOptionPane.showMessageDialog(null, "��������Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			}else if(string.isEmpty(creditText.getText())){
				JOptionPane.showMessageDialog(null, "���ֲ���Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			}else if(string.isEmpty(rankText.getText())){
				JOptionPane.showMessageDialog(null, "�ȼ�����Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			}else{
				int id = Integer.parseInt(IdText.getText());
				String name = nameText.getText();
				int credit = Integer.parseInt(creditText.getText());
				int rank = Integer.parseInt(rankText.getText());
				String phone = phoneText.getText();
				// ������ѯ�����
				try {
					Data db = new Data();
					Statement statement = db.getCon().createStatement();
					String sql = "update vip set name= '"+name+"',score='"+credit+"',rank='"+rank+"',phone='"+phone+"' where id= '"+id+"'";

					statement.execute(sql);
				
					db.getCon().close();
					} catch (ClassNotFoundException ee) {
						// ���ݿ��������쳣����
						System.out.println("Sorry,can`t find the Driver!");
						ee.printStackTrace();
					} catch (SQLException ee) {
						// ���ݿ�����ʧ���쳣����
						ee.printStackTrace();
					} catch (Exception ee) {
						ee.printStackTrace();
					}
				this.dispose();
				mana.refresh();
			}
		}	
	}
}
