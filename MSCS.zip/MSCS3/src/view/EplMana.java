package view;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import utils.Data;
import entity.User;

public class EplMana extends JFrame implements ActionListener {
	
	private JPanel contentPane;
	private JTable infoTable;
	private Vector<Object> ve; 
	private JButton add ;
	private JButton update;
	private JButton delete;
	private JButton search;
	private JButton refresh;
	private int DelID;
	private JButton Return;
	private User currentUser;

	
	public EplMana(User user)  {
		this.currentUser = user;
		
		setResizable(false);
		setTitle("Ա������");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 712, 474);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel showInfo = new JPanel();
		showInfo.setBounds(0, 46, 694, 381);
		contentPane.add(showInfo);
		showInfo.setLayout(null);
		String[] columnNames = {"���","����","ְλ","н��","��ְʱ��","״̬","�ֻ���"};
		Object[][] rowDatas = {};
		DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
		infoTable = new JTable(myModel);
		infoTable.setBounds(39, 13, 586, 322);
		
		try {
			getInfo();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
		// ���ñ���������ɫ
		infoTable.setForeground(Color.BLACK);                   // ������ɫ
		infoTable.setFont(new Font(null, Font.PLAIN, 14));      // ������ʽ
		infoTable.setSelectionForeground(Color.DARK_GRAY);      // ѡ�к�������ɫ
		infoTable.setSelectionBackground(Color.LIGHT_GRAY);     // ѡ�к����屳��
		infoTable.setGridColor(Color.GRAY);                     // ������ɫ

        // ���ñ�ͷ
		infoTable.getTableHeader().setFont(new Font(null, Font.BOLD, 14));  // ���ñ�ͷ����������ʽ
		infoTable.getTableHeader().setForeground(Color.RED);                // ���ñ�ͷ����������ɫ
		infoTable.getTableHeader().setResizingAllowed(false);               // ���ò������ֶ��ı��п�
		infoTable.getTableHeader().setReorderingAllowed(false);             // ���ò������϶������������
		 // �����и�
		infoTable.setRowHeight(30);
		
		JScrollPane scrollPane = new JScrollPane(infoTable);
		scrollPane.setBounds(0, 13, 694, 343);
		showInfo.add(scrollPane);
		
		JPanel function = new JPanel();
		function.setBounds(0, 0, 694, 47);
		contentPane.add(function);
		
		add = new JButton("����");
		add.setBounds(25, 0, 90, 34);
		add.addActionListener(this); 
		function.setLayout(null);
		if(currentUser.getPosition().equals("�ܾ���")){
			add.setEnabled(false);
		}
		function.add(add);
		
		update = new JButton("�޸�");
		update.setBounds(131, 0, 90, 34);
		update.addActionListener(this);
		function.add(update);
		
		delete = new JButton("ɾ��");
		delete.setBounds(251, 0, 83, 34);
		delete.addActionListener(this);
		function.add(delete);
		
		search = new JButton("����");
		search.setBounds(371, 0, 83, 34);
		search.addActionListener(this);
		function.add(search);
		
		refresh = new JButton("ˢ��");
		refresh.addActionListener(this);
		refresh.setBounds(486, 2, 83, 31);
		function.add(refresh);
		
		Return = new JButton("����");
		Return.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Choice choice=new Choice(currentUser);
				choice.setVisible(true);
			}
		});
		Return.setBounds(601, 2, 83, 31);
		function.add(Return);
}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(add)){
			EplAdd add = new EplAdd(this);
		}
		if(e.getSource().equals(refresh)){
			this.dispose();
			EplMana vw = new EplMana(currentUser);
			vw.setVisible(true);
		}
		if(e.getSource().equals(delete)){
			int del = infoTable.getSelectedRow();
			if(del == -1){
				JOptionPane.showMessageDialog(null, "δѡ��ɾ����¼", "����",JOptionPane.WARNING_MESSAGE);
			}else{
				DelID = Integer.parseInt(infoTable.getValueAt(del, 0).toString());
				int n = JOptionPane.showConfirmDialog(null, "�Ƿ�ȷ��ɾ��?", "��Ʒɾ��",JOptionPane.YES_NO_OPTION);//i=0/1  
				if(n==0){	
					try {
						delInfo();
						refresh();
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					
				}
				
			}
			
		}
		if(e.getSource().equals(update)){
			int row = infoTable.getSelectedRow();
			if(row == -1){
				JOptionPane.showMessageDialog(null, "δѡ����¼�¼", "����",JOptionPane.WARNING_MESSAGE);
			}else{
				EplUpdate alter = new EplUpdate(this);
				alter.setTemp(row);
				alter.setVisible(true);
				if(currentUser.getPosition().equals("ϵͳ����Ա")){
					alter.setTable2(infoTable);
				}else if(currentUser.getPosition().equals("�ܾ���")){
					alter.setTable(infoTable);
				}
			}
		}
		if(e.getSource().equals(search)){
			
			String id = JOptionPane.showInputDialog("��������Ա��ţ�");
			if(id==null){return;}
			if(id.equals("")){
				JOptionPane.showMessageDialog(null, "�����Ų���Ϊ�գ�", "����",JOptionPane.WARNING_MESSAGE);
			    return;
			}
			if(currentUser.getPosition().equals("ϵͳ����Ա")){
				SysSearch  s = new SysSearch(this);
				s.setId(id);
				try {
					s.getInfo();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}else if(currentUser.getPosition().equals("�ܾ���")){
				EplSearch sea = new EplSearch(this);
				sea.setId(id);
				try {
					sea.getInfo();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			
		}
	}

	public void getInfo()throws Exception{
		if(currentUser.getPosition().equals("ϵͳ����Ա")){
			
			String[] columnNames = {"���","����","ְλ","����","н��","��ְʱ��","״̬","�ֻ���"};
			Object[][] rowDatas = {};
			DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
			infoTable = new JTable(myModel);	
			Data db = new Data();
			Statement statement = db.getCon().createStatement();
			String sql = "select * from employee";

			ResultSet rs = statement.executeQuery(sql);
			
			while (rs.next()) {
				ve = new Vector<Object>();
				ve.addElement(rs.getString("id")); 
				ve.addElement(rs.getString("name"));
				ve.addElement(rs.getString("position"));
				ve.addElement(rs.getString("id_key"));
				ve.addElement(rs.getFloat("salary"));
				ve.addElement(rs.getDate("indate"));
				ve.addElement(rs.getString("state"));
				ve.addElement(rs.getString("phone"));
				myModel.addRow(ve);
			}
			rs.close();
			db.getCon().close();
		}else if(currentUser.getPosition().equals("�ܾ���")){
			String[] columnNames = {"���","����","ְλ","н��","��ְʱ��","״̬","�ֻ���"};
			Object[][] rowDatas = {};
			DefaultTableModel myModel = new DefaultTableModel(rowDatas,columnNames);
			infoTable = new JTable(myModel);
		
			Data db = new Data();
			Statement statement = db.getCon().createStatement();
			String sql = "select * from employee";

			ResultSet rs = statement.executeQuery(sql);
		
			while (rs.next()) {
				ve = new Vector<Object>();
				ve.addElement(rs.getString("id")); 
				ve.addElement(rs.getString("name"));
				ve.addElement(rs.getString("position"));
				ve.addElement(rs.getFloat("salary"));
				ve.addElement(rs.getDate("indate"));
				ve.addElement(rs.getString("state"));
				ve.addElement(rs.getString("phone"));
				myModel.addRow(ve);
			}
			rs.close();
			db.getCon().close();
		}	
	}
	public void delInfo() throws SQLException, Exception{
		
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		String sql = "delete from employee where id = '"+DelID+"'";

		statement.execute(sql);

		db.getCon().close();
	}
	public void refresh(){
		this.dispose();
		EplMana vw = new EplMana(currentUser);
		vw.setVisible(true);
	}

}
