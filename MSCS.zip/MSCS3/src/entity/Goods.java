package entity;

public class Goods {

	private int goodsID;//���
	private String goodsName;//����
	private int price;//�۸�
	private int number;//����
	private int repertory;//���
	private int sale;//���۳�
	private String demand;//����̶�
	
	public String getDemand() {
		return demand;
	}
	public void setDemand(String demand) {
		this.demand = demand;
	}
	public int getRepertory() {
		return repertory;
	}
	public void setRepertory(int repertory) {
		this.repertory = repertory;
	}
	public int getSale() {
		return sale;
	}
	public void setSale(int sale) {
		this.sale = sale;
	}
	public int getNumber() {
		return number;
	}
	public void setNumber(int number) {
		this.number = number;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public int getGoodsID() {
		return goodsID;
	}
	public void setGoodsID(int goodsID) {
		this.goodsID = goodsID;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public Goods() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Goods(int goodsID, int number) {
		super();
		this.goodsID = goodsID;
		this.number = number;
	}
	
	
	
}
