package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Goods;
import utils.Data;

public class Goodsdao {

	public Goods login(Connection con,Goods goods)throws Exception{
		Goods result=null;
		String sql="select * from goods where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1,goods.getGoodsID());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			result=new Goods();
			result.setGoodsName(rs.getString("name"));
			result.setGoodsID(rs.getInt("id"));
			result.setPrice(rs.getInt("price"));
			result.setRepertory(rs.getInt("repertory"));
			result.setSale(rs.getInt("sale"));
		}
		return result;
	}
	
	public void add(Goods goods) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		if(goods.getSale()>=0&&goods.getSale()<=200){
			goods.setDemand("С");
			String sql = "insert into goods(name,repertory,price,sale,demand) values ('"+goods.getGoodsName()+"','"+goods.getRepertory()+"','"+goods.getPrice()+"','"+goods.getSale()+"','"+goods.getNumber()+"')";
			statement.execute(sql);
		}else if(goods.getSale()>200&&goods.getSale()<=500){
			goods.setDemand("��");
			String sql = "insert into goods(name,repertory,price,sale,demand) values ('"+goods.getGoodsName()+"','"+goods.getRepertory()+"','"+goods.getPrice()+"','"+goods.getSale()+"','"+goods.getNumber()+"')";
			statement.execute(sql);
		}else if(goods.getSale()>500){
			goods.setDemand("��");
			String sql = "insert into goods(name,repertory,price,sale,demand) values ('"+goods.getGoodsName()+"','"+goods.getRepertory()+"','"+goods.getPrice()+"','"+goods.getSale()+"','"+goods.getNumber()+"')";
			statement.execute(sql);
		}
		db.getCon().close();
	}
	public void delete(Goods goods) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		String sql = "delete from goods where id = '"+goods.getGoodsID()+"'";

		statement.execute(sql);

		db.getCon().close();
	}
	public void search(Goods goods) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();	
		String sql = "select * from goods where id='"+goods.getGoodsID()+"'";
		ResultSet rs = statement.executeQuery(sql);
		rs.close();
		db.getCon().close();
	}
	public void update(Goods goods){
		String sql = "update goods set name= '"+goods.getGoodsName()+"',repertory='"+goods.getRepertory()+"',price='"+goods.getPrice()+"',sale='"+goods.getSale()+"',demand='"+goods.getNumber()+"' where id= '"+goods.getGoodsID()+"'";
	}
}
