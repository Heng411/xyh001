package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import entity.User;
import utils.Data;


/*�û�dao��*/
public class Userdao {

	public User login(Connection con,User user)throws Exception{
		User result=null;
		String sql="select * from employee where id=? and id_key=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1,user.getUserName());
		pstmt.setString(2,user.getPassword());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next()) {
			result=new User();
			result.setName(rs.getString("name"));
			result.setPassword(rs.getString("id_key"));
			result.setPosition(rs.getString("position"));
			result.setUserName(rs.getString("id"));
		}
		return result;
	}
	public void add(User user) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		String sql = "insert into employee(id,name,position,salary,indate,phone,state) values ('"+user.getUserName()+"','"+user.getName()+"','"+user.getPosition()+"','"+user.getSalary()+"','"+user.getIndate()+"','"+user.getPhone()+"','"+user.getState()+"')";
		statement.execute(sql);
		db.getCon().close();
	}
	public void delete(User user) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		String sql = "delete from employee where id = '"+user.getUserName()+"'";
		statement.execute(sql);
		db.getCon().close();
		
	}
	public void update(User user) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();
		String sql = "update employee set name= '"+user.getName()+"',position='"+user.getPosition()+"',salary='"+user.getSalary()+"',indate='"+user.getIndate()+"',phone = '"+user.getPhone()+"' where id= '"+user.getUserName()+"'";
		statement.execute(sql);
		db.getCon().close();
	}	
	public void search(User user) throws SQLException, Exception{
		Data db = new Data();
		Statement statement = db.getCon().createStatement();	
		String sql = "select * from employee where id='"+user.getUserName()+"'";

		ResultSet rs = statement.executeQuery(sql);
		if(rs.next()){
			user.setUserName(rs.getString("id"));
			user.setName(rs.getString("name"));
			user.setPosition(rs.getString("position"));
			user.setSalary(Float.parseFloat(rs.getString("salary")));
			user.setState(rs.getString("state"));
			user.setPhone(rs.getString("phone"));
		}
		else{
			JOptionPane.showMessageDialog(null, "��Ա������", "����",JOptionPane.WARNING_MESSAGE); 
		}

		rs.close();
		db.getCon().close();
		
	}
}
