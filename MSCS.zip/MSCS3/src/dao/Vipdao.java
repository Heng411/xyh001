package dao;

import entity.Vip;

public class Vipdao {
	
	public void add(Vip vip){
		
		String sql = "insert into vip(name,score,rank,phone) values ('"+vip.getName()+"','"+vip.getScore()+"','"+vip.getRank()+"','"+vip.getPhone()+"')";
	}
	public void update(Vip vip){
		String sql = "update vip set name= '"+vip.getName()+"',score='"+vip.getScore()+"',rank='"+vip.getRank()+"',phone='"+vip.getPhone()+"' where id= '"+vip.getId()+"'";
	}
	public void delete(Vip vip) throws Exception{
		
		String sql = "delete from vip where id = '"+vip.getId()+"'";
		
	}
	public void search(Vip vip){
		String sql = "select * from VIP where id='"+vip.getId()+"'";
	}
}
