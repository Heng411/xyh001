package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/*���ݿ�*/
public class Data{
	
	String driver = "com.mysql.cj.jdbc.Driver";
	String url = "jdbc:mysql://localhost:3306/store?serverTimezone=GMT&characterEncoding=UTF-8";
	String user = "root";
	String password = "000411";
	
/*��ȡ���ݿ�����*/	
	public Connection getCon()throws Exception{
		Class.forName(driver);
		Connection con = DriverManager.getConnection(url, user,password);
		return con;
	}
	
/*�ر����ݿ�*/	
	public void closeCon(Connection con)throws Exception{
		if(con!=null) {
			con.close();
		}
	}
}
